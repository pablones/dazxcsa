AppendAttribute.xml    附加道具属性
CoordinatesEquip.xml   套装信息
Properties.xml         道具信息

Config.xml 			   地图数据

GameSkill.xml		   游戏技能
